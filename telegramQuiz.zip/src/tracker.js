const { Markup} = require('telegraf');
const { getFreeQuestion } = require("./getFreeQuestion");
const { standardpayment, intermediatepayment, advancedpayment } = require('./payment');
const Sequelize = require("sequelize");
const models = require("../models");
const Op = Sequelize.Op;
exports.tracker = async(ctx) => {

}